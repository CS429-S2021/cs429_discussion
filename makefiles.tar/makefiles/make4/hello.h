// example include file

void func(void);
